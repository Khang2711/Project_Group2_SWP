> Cập nhật mới nhất: đọc README_FIX4.md. Bản fix4 dùng html5-qrcode phía trình duyệt và bật sẵn thanh toán giả lập để kiểm thử; các mô tả cũ về việc không có giả lập/giải mã QR máy chủ bên dưới đã được thay thế.

# F Cinema Big Update tháng 9 năm 2026

Bản nâng cấp mã nguồn Java Servlet/JSP và SQL Server từ FCinema_by_Group2.zip, đối chiếu phần chức năng, phân quyền và Business Rules của Group2_RDS Document (4).docx. Bỏ qua UI Design, các ô <<placeholder>>, ví dụ Order Meals, Setting và mẫu MD5 trong tài liệu. Giao diện mới dùng nền tối và điểm nhấn đỏ lấy cảm hứng từ Netflix.

Đây là **bản mã nguồn cần build và kiểm thử tích hợp**, chưa phải bản đã nghiệm thu để triển khai thật. Không kèm WAR cũ vì WAR trong ZIP đầu vào không phản ánh bản cập nhật này.

Đọc thêm `README_FIX2.md` cho bản sửa giao diện, UTF-8, camera và đặt vé.

## Chạy trên máy của bạn

1. Giải nén và mở thư mục F-Cinema1 dưới dạng Maven project trong NetBeans hoặc IDE đang dùng. Giữ Java 11 trở lên, Servlet Jakarta 6 / Tomcat 10.1 hoặc máy chủ Jakarta EE 10 tương thích. Không dùng Tomcat 9 (javax).
2. **Sao lưu database hiện có.** Chạy `database/BIG_UPDATE_20260911.sql` trong SQL Server Management Studio trên FCinemaDB. Script thêm bảng/cột và ràng buộc, không xóa toàn bộ dữ liệu. Khi tăng/giảm sức chứa phòng sau này, ghế được sinh/điều chỉnh tương ứng theo ràng buộc trong script.
3. Nếu CHƯA có database: chạy `database/FCinemaDB_100pct.sql` đúng một lần để tạo dữ liệu nền, rồi chạy BIG_UPDATE. **Không chạy lại FCinemaDB_100pct.sql trên dữ liệu cần giữ**: đây là script reset gốc có DROP TABLE và không dành cho nâng cấp.
4. Thiết lập các biến môi trường bên dưới cho tiến trình chạy Tomcat/IDE; khởi động lại tiến trình sau khi thay đổi. Ứng dụng đọc biến môi trường hoặc Java system property cùng tên; không tự đọc file `.env`.
5. Chạy `mvn clean package`. Maven cần tải các dependency trong pom.xml: SQL Server JDBC, Jakarta EE API, ZXing và Angus Mail. Deploy file WAR mới trong `target`.
6. Mở `/F-Cinema1-1.0-SNAPSHOT/movies` (context có thể khác theo cấu hình IDE).
7. Tài khoản AD cũ nay chỉ quản trị tài khoản. Đăng nhập tài khoản admin đang có, tạo tài khoản vai trò **MG** để quản lý phim/rạp và **ST** để soát vé. ST bắt buộc gán chi nhánh; US là khách hàng. Bản nâng cấp không tự tạo tài khoản có mật khẩu mặc định mới.
8. Đăng nhập MG, kiểm tra rạp, gán phòng vào chi nhánh, cập nhật cấu hình ghế, giá vé, độ tuổi và kỳ công chiếu trước khi đặt vé. Các phòng cũ được gán C01; ghế ban đầu là Standard. Mỗi phòng tối đa 260 ghế theo lưới A1–Z10 hiện tại.

## Cấu hình

| Biến | Giá trị / ý nghĩa |
| --- | --- |
| FCINEMA_DB_URL | Mặc định `jdbc:sqlserver://localhost:1433;databaseName=FCinemaDB;encrypt=true;trustServerCertificate=true` cho máy phát triển |
| FCINEMA_DB_USER | Mặc định `sa`; có thể dùng tài khoản SQL riêng |
| FCINEMA_DB_PASSWORD | Bắt buộc: mật khẩu SQL của bạn; đã bỏ mật khẩu hardcode khỏi Java |
| FCINEMA_PUBLIC_URL | URL gốc truy cập ứng dụng, gồm context path, không có dấu `/` cuối |
| VNPAY_TMN_CODE | Merchant code do VNPay cấp |
| VNPAY_HASH_SECRET | Khóa HMAC do VNPay cấp; chỉ đặt ở máy chủ |
| VNPAY_URL | Mặc định URL thanh toán sandbox của VNPay |
| SMTP_HOST | Máy chủ email SMTP |
| SMTP_PORT | Mặc định 587, STARTTLS bắt buộc |
| SMTP_USER / SMTP_PASSWORD | Thông tin xác thực SMTP |
| SMTP_FROM | Địa chỉ người gửi; mặc định SMTP_USER |

Đặt giờ SQL Server và JVM theo Asia/Ho_Chi_Minh cho lịch chiếu, thời hạn giữ ghế và VNPay. Khi triển khai thật, cấu hình JDBC xác thực chứng chỉ máy chủ thay vì tùy chọn tin chứng chỉ dùng cho localhost.

VNPay IPN cần truy cập được từ VNPay: đăng ký `<FCINEMA_PUBLIC_URL>/payment/ipn`. Return URL là `<FCINEMA_PUBLIC_URL>/payment/return`. Máy chỉ chạy localhost không tự nhận được IPN từ Internet; cần địa chỉ máy chủ kiểm thử có thể truy cập. Return URL chỉ hiển thị thông báo; **không phát hành vé dựa trên redirect trình duyệt**. Không có chế độ giả lập thanh toán thành công.

Bản sửa Fix 2: thiếu cấu hình VNPay vẫn tạo được đơn giữ ghế; trang checkout/đơn báo chưa thanh toán được và không phát hành vé. Thiếu SMTP: màn hình khôi phục thông báo dịch vụ chưa cấu hình. Camera cần HTTPS hoặc localhost ; nếu không có BarcodeDetector, trình duyệt gửi khung hình đến endpoint F-Cinema để đọc QR bằng ZXing. Có thêm lựa chọn ảnh QR và nhập mã vé. QR vé được sinh tại máy chủ bằng ZXing, không gửi mã vé qua dịch vụ tạo QR bên ngoài.

## Những gì thay đổi

| Nhóm | Hành vi mới |
| --- | --- |
| Giao diện | Đỏ–đen dùng chung cho đăng nhập, đăng ký, trang phim, chi tiết, chọn ghế, giỏ, thanh toán, lịch sử, hồ sơ và các trang vận hành; màn hình hẹp có bố cục co giãn |
| Phân quyền | US / ST / MG / AD độc lập; menu theo vai trò và filter kiểm tra phía máy chủ. AD không còn sửa phim hoặc xem doanh thu |
| Tài khoản | Admin tạo/sửa/khóa tài khoản, gán vai trò và chi nhánh. Không được tự khóa/hạ quyền tài khoản đang đăng nhập. Khóa/đổi vai trò được kiểm tra lại ở request tiếp theo |
| Mật khẩu | PBKDF2 với salt cho mật khẩu mới; đăng nhập được tài khoản MD5 cũ rồi tự nâng cấp. Đổi/reset mật khẩu làm phiên cũ mất hiệu lực khi truy cập tiếp |
| Hồ sơ | Họ tên, email khôi phục, điện thoại, ảnh đại diện qua URL HTTPS, ngày sinh; đổi email hoặc mật khẩu cần mật khẩu hiện tại |
| Khôi phục | Token ngẫu nhiên chỉ lưu SHA-256, hiệu lực 15 phút, dùng một lần; gửi liên kết bằng SMTP |
| Rạp và phòng | Thêm/sửa/ngừng hoạt động chi nhánh; quản lý phòng, gán phòng vào chi nhánh; sinh ghế theo sức chứa |
| Ghế và giá | Standard / VIP / Couple, bật/tắt ghế, giá theo chi nhánh/loại ghế/kỳ hiệu lực; cấm các chính sách hoạt động chồng kỳ. Chưa có chính sách thì dùng basePrice của phim |
| Phim và lịch | Xem cả phim hoạt động chưa mở lịch; tìm theo tên/ngày/rạp; độ tuổi và kỳ công chiếu; giờ kết thúc tính từ thời lượng. SQL kiểm tra chồng lịch và 15 phút dọn phòng |
| Đặt vé | Mỗi đơn một suất chiếu; kiểm tra ghế vật lý và giá từ DB. Bao rạp phải có đủ toàn bộ ghế khả dụng, không chỉ các ghế còn trống |
| Giữ ghế | Tạo đơn ở bước checkout và giữ ghế 10 phút; job chạy 30 giây/lần, đồng thời dọn hết hạn khi tạo/xem đơn. Ghế trong giỏ chưa được giữ |
| Ưu đãi | Mã phần trăm/số tiền, chi nhánh, kỳ hiệu lực, mức vé tối thiểu, số lượt. Giữ lượt cho đơn PENDING và tăng usedCount khi PAID. Hết hạn tự ngừng áp dụng |
| Thanh toán | Hiển thị tổng cuối cùng trên đơn rồi chuyển VNPay; HMAC, mã merchant, số tiền, hạn đơn và callback lặp được kiểm tra. Thanh toán thất bại/hết hạn giải phóng ghế |
| Vé và soát vé | Chỉ phát hành vé sau IPN thành công; QR chỉ đọc được bởi chủ vé. ST tra vé trong chi nhánh, kiểm tra phim/phòng/ghế/giờ và xác nhận độ tuổi trước check-in. Một vé dùng một lần |
| Báo cáo | Giữ báo cáo theo tháng và xuất Excel; các truy vấn doanh thu chỉ tính đơn đã thanh toán |

Quy ước cho phần tài liệu chưa chốt: MG quản lý tập trung toàn chuỗi như mô tả Actor; ST chỉ soát vé ở chi nhánh được gán. Mã quyền ngắn vẫn là AD/MG/ST/US để tương thích dự án. Giữ cấu trúc bảng tbl* cũ, mở rộng thêm bảng thay vì đổi toàn bộ tên sang sơ đồ minh họa. Khoảng nhận khách hiện là 30 phút trước giờ chiếu đến giờ kết thúc. Không hỗ trợ suất chiếu kết thúc sang ngày hôm sau với cấu trúc showDate/startTime/endTime hiện tại. Ghế Couple là một đơn vị ghế/vé theo mô hình hiện tại, chưa có quy tắc bắt buộc mua hai ghế liền nhau trong tài liệu.

## Kiểm tra đã thực hiện và giới hạn

- 80 kiểm tra logic Java đã qua: ma trận đường dẫn/quyền, PBKDF2, tương thích MD5, chữ ký VNPay, sửa số tiền và sai merchant. HMAC khớp phép tính độc lập bằng Python.
- Mã Java và phần Java của mọi JSP đã qua kiểm tra biên dịch với Java 11 target. Do thiếu thư viện thật tại môi trường kiểm tra, các API Servlet/SMTP/ZXing được thay bằng chữ ký API tối thiểu **chỉ cho kiểm tra tĩnh**, không đóng gói vào sản phẩm. Kết quả này không thay cho `mvn clean package` và JSP compilation trên Tomcat thật.
- Đã thực thi kết xuất HTML của các JSP đại diện với dữ liệu fixture để kiểm tra scriptlet. Chưa xác minh ảnh chụp giao diện bằng trình duyệt: trình duyệt kiểm tra không truy cập được server localhost ở môi trường này. Cần kiểm tra desktop/mobile thực tế.
- Chưa thực thi SQL migration trên SQL Server thật; chưa chạy các luồng đồng thời, VNPay sandbox, SMTP và camera thật. Chưa có build WAR mới. Cần thực hiện checklist dưới đây trước nghiệm thu.

Sau build, có thể chạy lại kiểm tra logic không cần dịch vụ ngoài: `java --class-path target/classes tests/LogicTest.java` (JDK 11+).

## Checklist chạy tích hợp trước nghiệm thu

1. Chạy SQL nâng cấp trên bản sao database. Chạy lại lần hai để kiểm tra khả năng áp dụng lặp; đối chiếu số lượng user/phim/phòng/vé trước và sau. Kiểm tra riêng quyền CREATE OR ALTER TRIGGER và CREATE INDEX.
2. Đăng nhập từng vai trò; thử truy cập trực tiếp URL của vai trò khác, thêm/sửa role bằng request giả, truy cập QR/vé/đơn của tài khoản khác. Kết quả phải 403/404 hoặc chỉ dữ liệu của mình.
3. Khóa user đang đăng nhập, đổi vai trò, đổi/reset mật khẩu; request kế tiếp không được giữ quyền cũ. Thử form thiếu/sai CSRF token.
4. Tạo rạp/phòng; ghế được sinh đủ. Thử sửa ghế/phòng/phim đang có vé hoặc giữ ghế; không được làm mất tính hợp lệ của vé. Thử giá chồng kỳ, âm, 0 và ưu đãi hết lượt/hết hạn/khác chi nhánh.
5. Tạo lịch trùng, sát nhau dưới 15 phút, ngoài kỳ chiếu, phòng hoặc rạp không hoạt động, phim bị khóa. Thử hai request tạo lịch đồng thời trong cùng phòng.
6. Hai trình duyệt đặt cùng một ghế đồng thời: chỉ một đơn giữ được ghế. Đợi hơn 10 phút; ghế được giải phóng và đơn thành EXPIRED. Thử bao rạp khi có một vé hoặc một ghế đang giữ; phải từ chối.
7. VNPay sandbox: thành công, thất bại/hủy, chữ ký sai, số tiền sai, merchant sai, IPN lặp và IPN tới sau hết hạn. Vé chỉ phát hành một lần với đơn còn hiệu lực; xác minh đối soát thủ công cho giao dịch thanh toán thành công nhưng IPN đến muộn.
8. Soát vé đúng/sai chi nhánh, ngoài giờ, chưa xác nhận độ tuổi; gửi hai xác nhận cùng lúc: chỉ một check-in thành công. Dùng camera trên thiết bị mục tiêu và nhập mã khi không có camera.
9. Reset email không tồn tại, token hết hạn, token dùng lại; kiểm tra không lộ thông tin tài khoản. Test SMTP và duyệt link trên ứng dụng thực tế.
10. Kiểm tra desktop 1440px và điện thoại 390px: đăng nhập, danh sách phim, poster có/không có ảnh, chọn ghế, bảng rộng, form quản lý. Dữ liệu poster gốc chưa có ảnh thì hiển thị tên phim bằng typography; thêm poster thật qua quản lý phim.

## Nguồn kỹ thuật

- Hợp đồng VNPay và cách phân biệt IPN/Return URL: https://sandbox.vnpayment.vn/apis/docs/thanh-toan-pay/pay.html
- ZXing QR: https://github.com/zxing/zxing
- SMTP implementation: https://eclipse-ee4j.github.io/angus-mail/
