package service;
import utils.DBUtils;import java.util.*;import java.net.URLEncoder;import java.nio.charset.StandardCharsets;import java.time.*;import java.time.format.DateTimeFormatter;import javax.crypto.Mac;import javax.crypto.spec.SecretKeySpec;import java.security.MessageDigest;
public final class VNPay {
 private static final Properties FILE_CONFIG=loadFileConfig();
 private static Properties loadFileConfig(){
  Properties values=new Properties();
  try(java.io.InputStream stream=VNPay.class.getResourceAsStream("/vnpay.properties")){
   if(stream!=null){
    java.io.PushbackReader reader=new java.io.PushbackReader(new java.io.InputStreamReader(stream,StandardCharsets.UTF_8),1);
    int first=reader.read();if(first!=-1&&first!=0xFEFF)reader.unread(first);
    values.load(reader);
   }
  }catch(java.io.IOException|IllegalArgumentException e){
   // Do not log exception text: malformed property values may include a secret.
   java.util.logging.Logger.getLogger(VNPay.class.getName()).warning("Khong doc duoc vnpay.properties. Kiem tra dinh dang file va trien khai lai.");
   values.clear();
  }
  return values;
 }
 private static String config(String key,String fallback){
  String value=DBUtils.config(key,null);
  if(value==null)value=FILE_CONFIG.getProperty(key);
  return value==null||value.isBlank()?fallback:value.trim();
 }
 public static List<String> missingConfiguration(){
  List<String> missing=new ArrayList<>();
  for(String key:List.of("VNPAY_TMN_CODE","VNPAY_HASH_SECRET","FCINEMA_PUBLIC_URL"))if(config(key,null)==null)missing.add(key);
  return missing;
 }
 public static boolean isConfigured(){return missingConfiguration().isEmpty();}
 public static String configurationNotice(){
  List<String> missing=missingConfiguration();
  return missing.isEmpty()?"":("VNPay chưa được cấu hình. Máy chủ chưa đọc được: "+String.join(", ",missing)+". Bản FIX5: điền src/main/resources/vnpay.properties, Clean and Build rồi triển khai lại.");
 }
 public static String required(String key){String v=config(key,null);if(v==null)throw new IllegalArgumentException(configurationNotice());return v;}
 public static String query(Map<String,String> params){List<String>parts=new ArrayList<>();new TreeMap<>(params).forEach((k,v)->{if(v!=null&&!v.isEmpty())parts.add(URLEncoder.encode(k,StandardCharsets.US_ASCII)+"="+URLEncoder.encode(v,StandardCharsets.US_ASCII));});return String.join("&",parts);}
 public static String sign(String data)throws Exception{Mac m=Mac.getInstance("HmacSHA512");m.init(new SecretKeySpec(required("VNPAY_HASH_SECRET").getBytes(StandardCharsets.UTF_8),"HmacSHA512"));StringBuilder h=new StringBuilder();for(byte b:m.doFinal(data.getBytes(StandardCharsets.UTF_8)))h.append(String.format("%02x",b));return h.toString();}
 public static boolean verify(Map<String,String> params)throws Exception{Map<String,String>p=new TreeMap<>(params);String supplied=p.remove("vnp_SecureHash");p.remove("vnp_SecureHashType");return required("VNPAY_TMN_CODE").equals(p.get("vnp_TmnCode"))&&supplied!=null&&MessageDigest.isEqual(sign(query(p)).getBytes(StandardCharsets.US_ASCII),supplied.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.US_ASCII));}
 public static String url(Map<String,Object>o,String ip)throws Exception{
  Map<String,String>p=new TreeMap<>();DateTimeFormatter f=DateTimeFormatter.ofPattern("yyyyMMddHHmmss");ZonedDateTime now=ZonedDateTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
  p.put("vnp_Version","2.1.0");p.put("vnp_Command","pay");p.put("vnp_TmnCode",required("VNPAY_TMN_CODE"));p.put("vnp_Amount",BookingService.money(o.get("totalAmount")).multiply(new java.math.BigDecimal(100)).toPlainString());p.put("vnp_CurrCode","VND");p.put("vnp_TxnRef",o.get("orderID").toString());p.put("vnp_OrderInfo","Thanh toan ve F Cinema "+o.get("orderID"));p.put("vnp_OrderType","other");p.put("vnp_Locale","vn");p.put("vnp_ReturnUrl",required("FCINEMA_PUBLIC_URL")+"/payment/return");p.put("vnp_IpAddr",ip);p.put("vnp_CreateDate",f.format(now));
  java.time.LocalDateTime expiry=((java.sql.Timestamp)o.get("expiresAt")).toLocalDateTime();p.put("vnp_ExpireDate",f.format(expiry));String data=query(p);return config("VNPAY_URL","https://sandbox.vnpayment.vn/paymentv2/vpcpay.html")+"?"+data+"&vnp_SecureHash="+sign(data);
 }
}
