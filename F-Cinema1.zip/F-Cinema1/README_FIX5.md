# FIX5 — VNPay chưa được cấu hình

Bản trước chỉ đọc Java System Properties (-D) và biến môi trường. Môi trường sửa mã không truy cập được Tomcat của bạn nên chưa xác định biến nào đang thiếu ở máy bạn. Bản này thêm cấu hình bằng file và thông báo tên biến thiếu; không thay đổi xác thực IPN hoặc tự xác nhận thanh toán.

## Cách dùng đơn giản

1. Giải nén ZIP mới, mở đúng project F-Cinema1. Giữ cấu hình SQL đang dùng.
2. Mở src/main/resources/vnpay.properties. Trong NetBeans có thể dùng tab Files để đi theo đường dẫn này.
3. Điền hai dòng VNPAY_TMN_CODE= và VNPAY_HASH_SECRET= bằng giá trị VNPay cấp; không thêm dấu nháy. FCINEMA_PUBLIC_URL đã điền URL ngrok bạn cung cấp. Nếu ngrok đổi địa chỉ, cập nhật dòng này; giữ /F-Cinema1, không có dấu / cuối.
4. Dừng Tomcat → Clean and Build project → Run. File được Maven đưa vào WEB-INF/classes/vnpay.properties trong WAR. Không sửa bản sao trong target vì Clean sẽ xóa nó.
5. Mở web qua ngrok, đăng nhập, tạo đơn mới và vào Đơn đặt vé. Nếu đủ 3 giá trị, nút Thanh toán qua VNPay sẽ xuất hiện. Việc nút xuất hiện chỉ xác nhận đọc được cấu hình, chưa xác nhận Merchant/key đúng hoặc IPN hoạt động.

Thông báo lỗi bản mới có chữ FIX5 và tên từng biến chưa đọc được. Nếu vẫn chỉ thấy nguyên thông báo cũ, có thể bạn đang chạy WAR/project cũ. Gửi ảnh thông báo mới; không gửi nội dung file chứa HashSecret.

## Thứ tự ưu tiên

VM Options (-D) > biến môi trường > vnpay.properties. Giá trị trống được bỏ qua. Nếu đã đặt giá trị mẫu hoặc giá trị sai trong VM Options/biến môi trường, xóa riêng các giá trị VNPay đó hoặc sửa chúng, rồi khởi động lại NetBeans/Tomcat để dùng giá trị trong file. Không xóa cấu hình SQL đang hoạt động.

File dùng UTF-8, hỗ trợ BOM của trình soạn thảo Windows và bỏ khoảng trắng đầu/cuối giá trị. Được đọc một lần khi lớp khởi tạo; sửa file cần build và triển khai lại.

Đây là cách tiện cho dự án local. Sau khi điền khóa thật, file và WAR sẽ chứa khóa; không commit hoặc chia sẻ ZIP/WAR đã điền khóa. Khóa không được in ra trang/log và file không nằm trong thư mục web công khai. Khi triển khai thật vẫn có thể dùng cấu hình bên ngoài qua VM Options/biến môi trường.

Không cần cập nhật SQL. IPN vẫn phải được đăng ký với VNPay như hướng dẫn trước; thiếu IPN không gây ra thông báo thiếu biến cấu hình này. Nút giả lập vẫn theo FCINEMA_DEMO_PAYMENT, muốn tắt thì đặt false trong môi trường/VM Options của Tomcat.

## Nếu đã sửa thêm project của bạn

Có thể ghép riêng 6 file từ ZIP thay vì thay cả project:
- src/main/java/service/VNPay.java
- src/main/java/controller/OrderServlet.java
- src/main/java/controller/BookingServlet.java
- src/main/webapp/WEB-INF/views/user/orders.jsp
- src/main/webapp/WEB-INF/views/user/checkout.jsp
- src/main/resources/vnpay.properties

Nếu có chỉnh sửa riêng trong các file trên, đối chiếu và ghép thay đổi trước khi build.

## Kiểm tra

Đã qua 7 trường hợp đọc cấu hình: không có file, giá trị trống, thiếu khóa, UTF-8 BOM/khoảng trắng, ưu tiên biến môi trường, ưu tiên -D, file sai định dạng không lộ khóa trong log. Java và scriptlet JSP được kiểm tra biên dịch bằng các chữ ký API tối thiểu. Chưa build WAR với dependency thật hoặc thanh toán VNPay trên máy của bạn.
