# Sửa HTTP 500 khi mở trang chọn ghế

Nguyên nhân tìm thấy: selectSeats.jsp khai báo biến vòng lặp `config`, trùng đối tượng ngầm định JSP `config`. Đã đổi thành `physicalSeat`. BookingServlet cũng không forward lại cùng JSP khi gặp ServletException/IOException để tránh che lỗi biên dịch ban đầu bằng ClassNotFoundException.

Kiểm tra: bổ sung biến ngầm định JSP vào bộ kiểm tra Java/scriptlet; mã cũ thất bại với lỗi “variable config is already defined”, mã mới biên dịch qua. Đây là kiểm tra tĩnh với API giả lập, chưa chạy Tomcat/SQL Server thật. Các thay đổi giao diện, camera, đặt vé của bản fix2 vẫn có trong gói.

## Triển khai trong NetBeans / Tomcat

1. Dừng Tomcat.
2. Thay mã nguồn bằng bản ZIP này (giữ cấu hình kết nối của bạn). Nếu đã dùng đúng fix2 và có chỉnh sửa riêng, chỉ cập nhật `src/main/webapp/WEB-INF/views/user/selectSeats.jsp` và `src/main/java/controller/BookingServlet.java`.
3. Trong thư mục CATALINA_BASE của Tomcat đang chạy, xóa riêng cache ứng dụng `work/Catalina/localhost/F-Cinema1` nếu có. Chỉ xóa cache này khi Tomcat đã dừng; không xóa database, conf hoặc ứng dụng khác. Có thể xem đường dẫn CATALINA_BASE trong Output lúc Tomcat khởi động.
4. Clean and Build project, sau đó Run để triển khai lại và khởi động Tomcat.
5. Đăng nhập, mở lịch chiếu rồi chọn một suất để đặt vé. Không cần chạy lại SQL cho bản sửa này.

Nếu còn lỗi, gửi phần Output của Tomcat bắt đầu từ lần mở trang đầu tiên, đặc biệt đoạn “Unable to compile class for JSP” và các dòng lỗi phía dưới. Ảnh ClassNotFoundException chỉ cho biết lớp JSP không tải được, không luôn chứa lỗi biên dịch ban đầu.

Tham khảo: https://jakarta.ee/specifications/pages/3.1/jakarta-server-pages-spec-3.1 (implicit objects); https://tomcat.apache.org/tomcat-10.1-doc/jasper-howto.html (Jasper compilation / scratchdir).
