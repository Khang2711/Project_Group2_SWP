> Cập nhật mới nhất: đọc README_FIX4.md. Bản fix4 dùng html5-qrcode phía trình duyệt và bật sẵn thanh toán giả lập để kiểm thử; các mô tả cũ về việc không có giả lập/giải mã QR máy chủ bên dưới đã được thay thế.

# Bản sửa 2 — Giao diện, tiếng Việt, camera và đặt vé

Bản sửa này cập nhật mã nguồn từ Big Update, không thay đổi database. Nếu đã chạy BIG_UPDATE_20260911.sql ở bản trước thì không cần chạy lại SQL và không cần reset dữ liệu.

## Cách thay bản đang chạy

1. Lưu lại cấu hình kết nối SQL, VNPay và SMTP của bạn.
2. Giải nén toàn bộ ZIP mới, mở project F-Cinema1. Dừng bản ứng dụng đang chạy.
3. Chạy Maven `mvn clean package` hoặc Clean and Build trong NetBeans, rồi triển khai WAR mới. Cần build cả Java vì có endpoint đọc QR mới; chỉ thay CSS/JSP sẽ không đủ.
4. Khởi động lại server và đăng nhập lại. Nhấn Ctrl+F5 để tải CSS mới; phiên bản đường dẫn CSS/JS đã đổi thành `20260911-fix2`.
5. Không chạy file SQL reset gốc. Nếu chưa nâng cấp database lần nào, chạy BIG_UPDATE_20260911.sql trên bản sao lưu trước khi dùng chức năng đặt vé mới.

## Nguyên nhân và phần đã sửa

| Vấn đề | Nguyên nhân tìm thấy trong mã | Sửa đổi |
| --- | --- | --- |
| Chữ sáng trên nền trắng | `.table-wrap`, `.hero`, `.movie-card` còn nền trắng từ CSS cũ trong khi chữ đã đổi màu sáng | Sửa ngay khai báo nền cũ, gom CSS về một file dùng chung, đặt màu cụ thể cho hàng bảng, trạng thái, thông báo, form và chế độ in |
| Tiếng Việt hiển thị sai | Một số JSP mới chỉ import hoặc include header, chưa có pageEncoding riêng; font chưa được đóng gói | Khai báo UTF-8 tại từng JSP và web.xml, form dùng UTF-8; thêm font WOFF hỗ trợ tiếng Việt chạy offline; tăng line-height, bỏ letter-spacing âm và hạn chế cắt tiêu đề |
| Camera không mở | Kiểm tra BarcodeDetector rồi thoát trước cả getUserMedia | Tách mở camera khỏi đọc QR. Thiếu native decoder thì dùng ZXing ở cùng máy chủ, không cần CDN |
| Camera trên nhiều thiết bị | Thiếu chọn camera và thông báo lỗi cụ thể | Chọn camera, ưu tiên camera sau nhưng có fallback, xử lý quyền bị từ chối/webcam bận/không có camera, hủy phiên mở cũ và tắt khi rời trang |
| Không có camera hoặc không dùng được quyền camera | Chỉ có nhập mã thủ công | Thêm đọc ảnh QR; ảnh/frame chỉ xử lý trong bộ nhớ máy chủ, không lưu file. Endpoint cần phiên Staff và CSRF |
| Bỏ qua bước kiểm tra đơn | Nút Thanh toán trong giỏ dùng POST thẳng `/checkout` | Dùng GET để mở trang kiểm tra đơn, nhập ưu đãi; POST chỉ tạo đơn khi người dùng xác nhận |
| Đơn chờ cũ chặn đặt vé mới | Session PENDING_ORDER luôn được dùng lại kể cả giỏ đã có lựa chọn mới | Chỉ quay lại đơn chờ khi giỏ trống; giỏ mới tạo đơn mới |
| Một phần ghế bị thêm dù báo lỗi | Vừa kiểm tra từng ghế vừa thêm vào giỏ | Kiểm tra toàn bộ lựa chọn và ghế đang giữ trước khi thay đổi giỏ; giữ kiểm tra transaction khi tạo đơn |
| Chọn combo lỗi rồi mất dữ liệu | Xóa giỏ combo trước khi xác thực số lượng | Kiểm tra tất cả số lượng 0–20 rồi mới thay thế giỏ combo |
| Chưa cấu hình VNPay không tạo được đơn | Kiểm tra cấu hình cổng thanh toán ngay đầu bước tạo đơn | Vẫn tạo đơn giữ ghế được, nhưng hiện rõ chưa thanh toán trực tuyến được. Vé chỉ sinh sau xác nhận thanh toán hợp lệ; không giả lập thành công |
| Lỗi đặt vé hiện sai trang | Mọi lỗi GET đều forward về chọn ghế | Trả lỗi về đúng trang giỏ, checkout, chọn ghế hoặc lịch sử; phân biệt xung đột ghế, thiếu bảng/cột và lỗi tạm thời |

## Lưu ý để camera chạy thực tế

- Trên máy chạy Tomcat: mở bằng `http://localhost:<port>/<context>/staff/checkin`, rồi cho phép Camera.
- Trên điện thoại mở web bằng `http://192.168.x.x:...`: trình duyệt chặn getUserMedia vì địa chỉ HTTP không an toàn. Cần HTTPS với chứng chỉ được thiết bị tin cậy. Đổi JavaScript không thể gỡ giới hạn này; không cần tắt bảo mật trình duyệt.
- Nếu chưa có HTTPS, chọn ảnh QR hoặc nhập mã vé; tính năng đọc ảnh không cần quyền live camera.
- Nếu lỗi NotAllowedError: kiểm tra quyền Camera của trang và hệ điều hành. Nếu NotReadableError: đóng phần mềm khác đang chiếm webcam. Mở trang trực tiếp thay vì trong iframe.
- Nếu camera mở nhưng chưa đọc được QR: bảo đảm đã deploy Java mới, ZXing có trong WAR, đăng nhập ST còn hiệu lực và server nhận được POST `/staff/qr-decode`.
- Máy chủ chỉ đọc và trả mã; việc xác minh vé/chi nhánh và xác nhận vào rạp vẫn qua bước soát vé hiện có. Quét QR không tự đánh dấu vé đã sử dụng.

## Kiểm tra đặt vé

Luồng đúng: khách hàng US → chọn ghế → thêm vào giỏ → cập nhật combo nếu cần → Tiếp tục thanh toán → nhập mã ưu đãi → Giữ ghế & xem thanh toán → thanh toán trên đơn.

Nếu chưa có VNPay, bạn kiểm tra được việc tạo đơn, giữ ghế và hết hạn; chưa thể phát hành vé thanh toán thật. Muốn thử thanh toán đầy đủ cần cấu hình VNPay sandbox và IPN truy cập được từ VNPay theo README_BIG_UPDATE.md. Không có chế độ tự xác nhận thanh toán.

Nếu trang báo dữ liệu đặt vé chưa cập nhật, kiểm tra đã chạy BIG_UPDATE_20260911.sql chưa. Database cần tblSeats, tblReservations, tblPricing, tblPromotions và các cột mới của tblOrders/tblUsers. Nếu suất chiếu cũ đã qua ngày, quản lý tạo lịch chiếu tương lai. Phim có giới hạn tuổi cần khách hàng cập nhật ngày sinh.

## Giới hạn của việc sửa tiếng Việt

Các JSP hiện được lưu UTF-8 và font có đủ ký tự đang dùng. Nếu dữ liệu trong SQL đã lưu thành `???` hoặc ký tự sai từ trước, đổi font không khôi phục được chữ gốc; cần nhập lại trường đó từ dữ liệu đúng. Không tự chuyển mã hàng loạt dữ liệu vì có thể làm hỏng tên phim/tài khoản đang đúng.

## Kiểm tra đã thực hiện

- Biên dịch kiểm tra Java và scriptlet JSP với target Java 11; các chữ ký API Servlet/ZXing/SMTP được dựng tối thiểu cho kiểm tra tĩnh vì chưa có bộ chạy và dependency thật tại môi trường này. Không đóng gói các stub vào ZIP.
- Kiểm tra cú pháp JavaScript; 9 tình huống camera mô phỏng đã qua: không có BarcodeDetector, HTTP bị chặn, từ chối quyền, quét thành công một lần, mã không phải vé, hết phiên, native không có QR, hủy khi đang chờ camera và rời trang.
- Hai font WOFF bao phủ toàn bộ 108 ký tự Latin/tiếng Việt xuất hiện trong JSP. Kiểm tra UTF-8, XML, một CSS duy nhất, form POST có CSRF và luồng GET checkout.
- 6 cặp màu đã sửa có tỷ lệ tương phản từ 9.12 đến 15.31:1; đây là kiểm tra giá trị màu, không phải audit toàn bộ ảnh chụp trình duyệt.
- Chưa chạy thử webcam vật lý, database SQL Server, thanh toán thật hoặc build WAR mới tại đây. Trình duyệt kiểm tra không cho mở bản HTML cục bộ, nên không có xác nhận hình ảnh desktop/mobile từ trình duyệt trong lượt này. Cần kiểm tra trên ứng dụng sau deploy.

Chạy test camera bằng Node: `node tests/qr-scanner.test.cjs`. Test chỉ dùng giả lập media/DOM, không mở webcam và không gửi dữ liệu mạng.

Tài liệu về điều kiện mở camera và khả năng hỗ trợ:
https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
https://developer.mozilla.org/en-US/docs/Web/API/BarcodeDetector
