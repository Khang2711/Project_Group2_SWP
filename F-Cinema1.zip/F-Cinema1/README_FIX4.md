# Fix 4: html5-qrcode và thanh toán giả lập

Bản này bao gồm fix2 giao diện/tiếng Việt và fix3 lỗi biên dịch trang chọn ghế.

## Chạy bản mới

Dừng Tomcat, giữ lại cấu hình SQL của bạn, mở mã nguồn mới rồi Clean and Build → Run trong NetBeans. Nhấn Ctrl+F5. Phải triển khai cả Java, JSP, JavaScript và assets/vendor; chỉ thay JSP là chưa đủ. Không cần SQL mới nếu đã nâng cấp database bằng BIG_UPDATE_20260911.sql.

## QR đọc trên trình duyệt

Đóng gói html5-qrcode 2.3.8 và giấy phép Apache 2.0 tại assets/vendor/html5-qrcode. Thư viện lấy từ gói npm chính thức, không cần Internet/CDN khi sử dụng. WebRTC mở camera, decoder của html5-qrcode đọc QR trên thiết bị; không phụ thuộc BarcodeDetector. Không gửi frame hoặc ảnh tới endpoint ZXing cũ. Chỉ mã vé đã đọc được mới gửi POST kiểm tra vé, có CSRF và phân quyền Staff như trước.

Camera quét toàn khung hình ở 12 fps, có chọn camera, dừng khi đổi camera/rời trang, chống gửi trùng mã. Có thể chọn ảnh PNG/JPG/WebP tối đa 10 MB, xử lý ngay trên trình duyệt. Quét được mã sẽ mở bước kiểm tra vé, không tự xác nhận vào rạp.

Camera vẫn cần HTTPS hoặc localhost và quyền Camera. Điện thoại mở địa chỉ HTTP IP LAN không có quyền WebRTC; dùng HTTPS được thiết bị tin cậy hoặc chọn ảnh QR. Chọn ảnh không cần quyền camera. Không tắt bảo mật trình duyệt.

## Nút thanh toán giả lập

Bản kiểm thử này BẬT SẴN tính năng theo yêu cầu. Khách hàng đặt ghế → giỏ vé → kiểm tra đơn → tạo đơn giữ ghế → Đơn đặt vé → **Giả lập đã thanh toán thành công** → **Xem vé đã phát hành**.

Nút chỉ hiện cho đơn PENDING. Máy chủ kiểm tra tài khoản sở hữu đơn và hạn giữ ghế, lấy số tiền từ database, dùng chung transaction phát hành vé như VNPay. Ghi tblPayments.paymentID với tiền tố DEMO- và resultCode DEMO. Không thu tiền thật. Trang đơn hiển thị nhãn GIAO DỊCH GIẢ LẬP. Bấm lại không tạo vé lần hai; đơn hết hạn không phát hành vé. Nếu lỗi trong transaction thì rollback. Endpoint VNPay vẫn kiểm tra chữ ký và số tiền như trước.

Vé giả lập là dữ liệu thật trong database dùng để test, nên chiếm ghế và được tính vào báo cáo doanh thu hiện có. Hãy dùng database kiểm thử. Không tự xóa hay reset dữ liệu.

Tắt sau khi test: đặt biến môi trường FCINEMA_DEMO_PAYMENT=false cho tiến trình Tomcat, hoặc thêm -DFCINEMA_DEMO_PAYMENT=false vào Java Options rồi khởi động lại Tomcat. Cấu hình này vừa ẩn nút vừa chặn thao tác ở máy chủ. Đặt true để bật lại. Không cần cấu hình VNPay để dùng giả lập.

## Thử toàn bộ luồng

1. Khách US chọn suất chiếu còn mở bán, đặt ghế, tạo đơn và bấm giả lập trong vòng 10 phút.
2. Mở Vé của tôi và hiển thị QR hoặc lưu ảnh QR.
3. Đăng nhập ST bằng trình duyệt/thiết bị khác, thuộc đúng chi nhánh của vé; mở Soát vé, bật camera hoặc chọn ảnh QR vừa lưu.
4. Sau khi hiện thông tin vé, xác nhận kiểm tra tuổi rồi xác nhận vào rạp. Hệ thống chỉ cho vào từ 30 phút trước giờ chiếu đến giờ kết thúc; để test ngay hãy tạo suất phù hợp thời gian máy chủ.
5. Quét lại vé đã xác nhận: hệ thống phải báo đã sử dụng. Thử Staff chi nhánh khác: phải từ chối vé.

## Kiểm tra tại môi trường sửa mã

- 10 tình huống vòng đời html5-qrcode bằng API giả lập đã qua: đọc thành công/chống lặp, QR không hợp lệ, HTTP không an toàn, từ chối quyền, đổi camera, hủy camera đang mở, ẩn trang, đọc ảnh, ảnh không đọc được, thiếu thư viện. Chạy: node tests/qr-scanner.test.cjs.
- 7 tình huống dịch vụ thanh toán với JDBC mô phỏng đã qua: tắt giả lập, khác chủ đơn, hết hạn, thành công/bấm lặp, rollback khi ghi thanh toán lỗi, VNPay sai số tiền, VNPay thành công. Đây không phải thử nghiệm SQL Server thật hoặc kiểm tra đồng thời nhiều kết nối.
- Java và scriptlet JSP đã biên dịch kiểm tra tĩnh, bao gồm biến ngầm định JSP để bắt lỗi config của fix3. Môi trường chưa build WAR với dependency đầy đủ.
- Chưa chạy camera vật lý, kiểm tra hình ảnh trên trình duyệt hoặc SQL Server thực tế. Cần chạy các bước thử ở trên sau triển khai.

Tài liệu API: https://scanapp.org/html5-qrcode-docs/docs/apis/classes/Html5Qrcode
